
import java.time.Instant;
import java.util.Date;

public class Test {

    public static void main(String[] args) {
        Memur memur = new Memur("Temizlik", 4567, 1235, "ahmet", "bal", "erkek", 1234, "05457891245", "a@mail.com", null);
        memur.Kimlik_Bilgisi_Yazdir();
    }
}
