
public interface Gozlemlenebilir {
    public void Kimlik_Bilgisi_Yazdir();
}
