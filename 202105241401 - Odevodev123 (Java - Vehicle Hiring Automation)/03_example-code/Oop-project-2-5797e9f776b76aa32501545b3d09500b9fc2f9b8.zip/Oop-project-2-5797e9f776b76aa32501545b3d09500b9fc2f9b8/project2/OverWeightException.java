/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project2;

/**
 *
 * @author meltem koc
 */
public class OverWeightException extends Exception{
        private static final long serialVersionUID = -5978672169913817674L;

	public OverWeightException(String message) {
		super(message);
	}
    
}
