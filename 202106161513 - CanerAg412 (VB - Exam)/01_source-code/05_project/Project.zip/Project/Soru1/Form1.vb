﻿Imports System.IO

Public Class Form1
    Private Sub btnHesapla_Click(sender As Object, e As EventArgs) Handles btnHesapla.Click
        If txtAdet.Text = "" Or txtBirimFiyat.Text = "" Or txtUrunAd.Text = "" Then
            MsgBox("İlgili alanları doldurunuz !")
            Return
        End If
        Dim dosya As New StreamWriter("KDV.txt")
        Dim kdvDurum As String = "dahil degil"
        If chKdv.Checked Then
            kdvDurum = "dahil"
        End If
        dosya.WriteLine(txtUrunAd.Text + "," + txtBirimFiyat.Text + "," + txtAdet.Text + "," + kdvDurum)
        dosya.Close()
        MsgBox("Kaydedildi.")
    End Sub
End Class
