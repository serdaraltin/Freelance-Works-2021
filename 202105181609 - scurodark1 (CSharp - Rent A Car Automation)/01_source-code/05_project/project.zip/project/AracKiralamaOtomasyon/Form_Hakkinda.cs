﻿using System.Windows.Forms;

namespace AracKiralamaOtomasyon
{
    public partial class Form_Hakkinda : Form
    {
        public Form_Hakkinda()
        {
            InitializeComponent();
        }
    }
}
