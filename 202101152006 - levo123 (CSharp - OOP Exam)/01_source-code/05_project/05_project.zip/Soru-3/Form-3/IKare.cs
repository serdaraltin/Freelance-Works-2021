﻿namespace Form_3
{
    interface IKare
    {
        int kare(int a);
    }
}
