﻿namespace Form_3
{
    class KareIslemler : TemelIslemler
    {
        public int kare(int a)
        {
            return carp(a, a);
        }

    }
}
