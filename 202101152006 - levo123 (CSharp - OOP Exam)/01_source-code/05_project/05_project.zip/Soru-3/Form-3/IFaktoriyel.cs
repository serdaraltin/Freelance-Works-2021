﻿namespace Form_3
{
    interface IFaktoriyel
    {
        int fakt(int a);
    }
}
