﻿namespace Form_3
{
    interface kup
    {
        int kup(int a);
    }
}
