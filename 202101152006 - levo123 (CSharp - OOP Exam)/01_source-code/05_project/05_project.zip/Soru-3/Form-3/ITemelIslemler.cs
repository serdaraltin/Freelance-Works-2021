﻿namespace Form_3
{
    interface ITemelIslemler
    {
        int topla(int a, int b);
        int cikar(int a, int b);
        int bol(int a, int b);
        int carp(int a, int b);
    }
}
