﻿namespace Form_2
{
    interface ITest<T>
    {
        void Ekle(T deger);
    }
}
