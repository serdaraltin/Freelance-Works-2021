package Test;


import View.View_Menu;


public class Main {

    public static void main(String[] args) {
       new View_Menu();
    }

}
