package Interface;

public interface Interface_Oyun {
	public abstract void updateComponent();
	public abstract void drawComponent();
}
