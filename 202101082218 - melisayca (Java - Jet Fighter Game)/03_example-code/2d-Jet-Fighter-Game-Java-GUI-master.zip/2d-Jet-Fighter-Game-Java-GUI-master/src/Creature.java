
public abstract class Creature extends Entity{

	
	
	public Creature(float x, float y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}

	
}
