# jetFighter
A single player Jet Fighter game.
Users can keep their high score for this purpose users should register and log in in order to play the game.
Enemy planes randomly generated and they act without AI.

Notes
----------------------------------------
1-Keeping high scores in progress.
