
package gamemain;

import java.awt.Graphics2D;


public class GameEngine {
    int x,y;
    public GameEngine(int x,int y){
        this.x=x;
        this.y=y;
    }
    public void update(){
        
    }
    public void draw(Graphics2D g2d){
        
    }
}
