# JetFighter

Java Swing and AWT example.

## Main Class
**JetFighter.java**

## Screenshots

![MacDown Screenshot](https://raw.githubusercontent.com/buraksahin/JetFighter/master/simage/s1.png)

![MacDown Screenshot](https://raw.githubusercontent.com/buraksahin/JetFighter/master/simage/s2.png)