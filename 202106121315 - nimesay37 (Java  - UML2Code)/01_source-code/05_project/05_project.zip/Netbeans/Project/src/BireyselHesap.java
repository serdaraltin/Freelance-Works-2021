public class BireyselHesap extends Hesap {

    @Override
    public int masrafHesapla() {
        return 0;
    }
}
