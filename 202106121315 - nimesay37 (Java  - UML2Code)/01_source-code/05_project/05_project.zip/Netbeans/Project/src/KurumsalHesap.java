
public class KurumsalHesap extends Hesap {

    @Override
    public int masrafHesapla() {
        return 0;
    }
}