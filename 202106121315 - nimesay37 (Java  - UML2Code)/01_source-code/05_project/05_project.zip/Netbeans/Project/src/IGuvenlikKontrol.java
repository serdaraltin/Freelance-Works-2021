
public interface IGuvenlikKontrol {

    public void yetkiKontrol();
}