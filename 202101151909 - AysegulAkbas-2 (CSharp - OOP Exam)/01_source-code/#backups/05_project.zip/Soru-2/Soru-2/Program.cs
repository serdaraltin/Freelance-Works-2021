﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Soru_2
{
    interface inf<A>
    {
        bool DiziyeAt(A eklenecek);
    }

    class Sınıf<A> : inf<A>
    {
        A[] dizi = new A[100];
        public int i = 0;
        public bool DiziyeAt(A eklenecek)
        {
            if (i >= 100)
                return false;
            dizi[i++] = eklenecek;
            return true;
        }

        public A this[int i]{
            get
            {
                return dizi[i];
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
             Sınıf<int> sinif = new Sınıf<int>();

            sinif.DiziyeAt(4);
            sinif.DiziyeAt(10);
            sinif.DiziyeAt(21);
            sinif.DiziyeAt(12);
            sinif.DiziyeAt(6);

            for (int i = 0; i < sinif.i; i++)
            {
                Console.WriteLine(sinif[i]);  
            }
            Console.ReadKey();
        }
    }
}
