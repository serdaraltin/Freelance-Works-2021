﻿namespace Soru_2_Form
{
    interface inf<A>
    {
        bool DiziyeAt(A eklenecek);
    }
}