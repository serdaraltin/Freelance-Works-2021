﻿using System;
using System.Collections;

namespace Soru_3
{
    interface kullanici
    {
        void BilgileriYazdir();
    }
    class Kullanici : kullanici
    {
        public string ad;
        public string sehir;
        public void BilgileriYazdir()
        {
            Console.WriteLine("Ad : " + ad);
            Console.WriteLine("Sehir : " + sehir);
        }
    }
  

    interface isyeri
    {
        void IsyeriYazdir();
    }
    class Isyeri : Kullanici, isyeri
    {
        public string isyeri;
        public void IsyeriYazdir()
        {
            Console.WriteLine("İşyeri : " + isyeri);

        }
    }

    interface detay
    {
        void YasYazdir();
    }
    class Detay : Isyeri, detay
    {
        public int yas;
        public void YasYazdir()
        {
            Console.WriteLine("Yaş : " + yas);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Detay d = new Detay();
            d.ad = "Ahmet";
            d.sehir = "İstanbul";
            d.isyeri = "Lobrowa";
            d.yas = 32;

            d.BilgileriYazdir();
            d.IsyeriYazdir();
            d.YasYazdir();

            Console.ReadKey();

        }
    }

}