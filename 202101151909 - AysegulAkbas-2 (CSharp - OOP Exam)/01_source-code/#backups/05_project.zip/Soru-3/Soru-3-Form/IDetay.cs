﻿using System.Windows.Forms;
namespace Soru_3_Form
{
    interface IDetay
    {
        void YasYazdir(RichTextBox ric);
    }
}
