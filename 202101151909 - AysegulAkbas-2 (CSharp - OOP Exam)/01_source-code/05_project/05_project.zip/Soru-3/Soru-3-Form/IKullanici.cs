﻿using System.Windows.Forms;
namespace Soru_3_Form
{
    interface IKullanici
    {
        void BilgileriYazdir(RichTextBox ric);
    }
}
