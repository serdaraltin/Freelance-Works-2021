﻿using System.Windows.Forms;

namespace Soru_3_Form
{
    interface Iİsyeri
    {
        void IsyeriYazdir(RichTextBox ric);
    }
}
