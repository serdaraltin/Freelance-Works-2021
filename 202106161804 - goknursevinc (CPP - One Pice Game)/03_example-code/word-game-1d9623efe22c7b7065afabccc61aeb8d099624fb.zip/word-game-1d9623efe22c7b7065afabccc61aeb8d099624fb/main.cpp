#include<iostream>
#include<vector>
#include<set>
#include<string>
#include<fstream>
#include <cstdlib>
#include <ctime>
#include "header.h"
using namespace std;

int main() 
{	
	Words W;
	W.playgame(W);
	return 0;
}