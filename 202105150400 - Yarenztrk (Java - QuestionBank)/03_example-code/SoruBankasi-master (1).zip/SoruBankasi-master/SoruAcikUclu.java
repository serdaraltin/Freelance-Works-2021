//@mehmet uysal, last update: 03/05/2020


public class SoruAcikUclu extends Soru{
	
	public SoruAcikUclu(String soruMetni, int zorluk) {
		super(soruMetni, zorluk, 'a');	//a = acik uclu
	}
	
}
