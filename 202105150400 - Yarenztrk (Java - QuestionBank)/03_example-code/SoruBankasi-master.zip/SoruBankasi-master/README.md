# SoruBankasi
Java kullanılarak yapılmış soru bankası
