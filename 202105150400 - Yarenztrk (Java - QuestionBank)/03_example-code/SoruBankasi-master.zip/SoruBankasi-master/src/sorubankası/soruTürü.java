
package sorubankası;

public class soruTürü extends soru{
    


	
	public int getSoruTipi() {
		return soruTürü;
	}

	public void setSoruTipi(int soruTürü) {
		this.soruTürü = soruTürü;
	}
	
}