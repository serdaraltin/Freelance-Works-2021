
package sorubankası;


public class dogruCevap extends soru {
	
	public String getDogruCevap() {
		return dogruCevap;
	}

	public void setDogruCevap(String dogruCevap) {
		this.dogruCevap = dogruCevap;
	}
	
}
