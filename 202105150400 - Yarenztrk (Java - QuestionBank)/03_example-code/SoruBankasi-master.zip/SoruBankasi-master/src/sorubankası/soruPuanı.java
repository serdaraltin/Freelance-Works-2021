
package sorubankası;

    
    public class soruPuanı extends soru{

	public int getPuan() {	
		return soruPuani;
	}

	public void setPuan(int soruPuani) {
		this.soruPuani = soruPuani;
	}
	
}

