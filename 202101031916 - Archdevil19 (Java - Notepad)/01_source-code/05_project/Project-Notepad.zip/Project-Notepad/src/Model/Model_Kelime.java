package Model;

public class Model_Kelime {
    
    char ayraclar[] = {'.', ',', ';', ' '};
    char birlestiriciler[] = {'-'};
    
}
