package Interface;


public interface Interface_Bul<T> {

    public boolean Bul(T veri);

    public int SonrakiniBul(T veri);

}
