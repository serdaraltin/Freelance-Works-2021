package Interface;

public interface Interface_Degistir<T> {

    public void Degistir(T veri);

    public void TumunuDegistir(T veri);
}
